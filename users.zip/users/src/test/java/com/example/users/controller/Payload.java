package com.example.users.controller;

public class Payload {
    public static String userPayload(){
        return "{\"id\":\"612\",\"firstName\":\"java\",\"middleName\":\"ds\",\"email\":\"test1@gmail.com\",\"\"roles\":[\"hr\"],\"contact\":\"123\"}";
    }

}
