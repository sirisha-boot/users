//package com.example.users.controller;
//
//import com.example.users.model.AuthRequest;
//import com.example.users.model.User;
//import com.example.users.service.UserService;
//import com.fasterxml.jackson.core.JsonProcessingException;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.DisplayName;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.boot.test.mock.mockito.MockBean;
//import org.springframework.http.MediaType;
//import org.springframework.security.test.context.support.WithMockUser;
//import org.springframework.test.context.junit.jupiter.SpringExtension;
//import org.springframework.test.web.servlet.MockMvc;
//import org.springframework.test.web.servlet.ResultActions;
//
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Optional;
//
//import static org.hamcrest.CoreMatchers.is;
//import static org.mockito.ArgumentMatchers.any;
//import static org.mockito.BDDMockito.given;
//import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
//import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
//import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
//import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
//
//
//@SpringBootTest
//@ExtendWith(SpringExtension.class)
//@AutoConfigureMockMvc
//public class UserControllerTest {
//    @Autowired
//    MockMvc mockMvc;
//
//    @MockBean
//    UserService userService;
//    private ObjectMapper objectMapper = new ObjectMapper();
//
// User user;
// //UserReponse userReponse;
// String userJson;
//
// AuthRequest authRequest;
//
//    Optional<User> optionalUser;
//
//
//UserController uc= new UserController();
//
//
//
// @BeforeEach
// void setup() throws JsonProcessingException {
//
//
//     List<String> managerName = new ArrayList<>();
//     managerName.add("hr");
////     roles.add("manager");
//
//     user = User.builder()
//             .id("123")
//             .firstName("java")
//             .middleName("bo")
//             .email("userkn@test.com")
//             .contact("1234")
//             .managerName(managerName).build();
//
////     userReponse = UserReponse.builder()
////             .id("123")
////             .roles(roles)
////             .email("user@gmail.com")
////             .build();
////set here to optional  k do
//     optionalUser = Optional.of(user);
//     authRequest = AuthRequest.builder()
//             .userName("Java")
//             .password("pswd")
//             .build();
//
//     userJson = objectMapper.writeValueAsString(user);
//
// }
//
//    @Test
//    @DisplayName("create user 200 status check")
//    @WithMockUser(username = "admin",roles = {"ADMIN","USER"})
//     public    void givenUser_whenCallCreateUserEntity_thenUserResponse() throws Exception {
//     //given(customUserDetailsService.loadUserByUsername(authRequest.getUserName())).willReturn(userDetails);
//        given(userService.getUserByEmailEntity(any(String.class))).willReturn(optionalUser.empty());
//        given(userService.createUser(user)).willReturn(user);
//        ResultActions response = mockMvc.perform(post("/users")
//                .contentType(MediaType.APPLICATION_JSON)
//                .content(userJson));
//        //then
//        response.andExpect(status().isCreated())
//                .andExpect(jsonPath("$.id").value("123"))
//                      //  is(user.getId())))
//               .andExpect(jsonPath("$.roles").value("hr")); //is(user.getRoles())));
// }
//
//    @Test
//    @DisplayName("Throw exception when emailId already exists")
//    @WithMockUser(username = "admin",roles = {"ADMIN","USER"})
//    void givenUser_whenCallCreateUser_thenReturnBadRequest() throws Exception {
//        given(userService.getUserByEmailEntity(any(String.class))).willReturn(Optional.ofNullable(user));
//
//        ResultActions response = mockMvc.perform(post("/users")
//                .contentType(MediaType.APPLICATION_JSON)
//                .content(userJson));
//        //then
//        response.andExpect(status().isUnprocessableEntity())
//                .andExpect(jsonPath("$.errCode").value("422"))//is("422")))
//                .andExpect(jsonPath("$.url", is("https://modeeleven.com/docs/error-codes")))
//                .andExpect(jsonPath("$.msg", is("Email already exists. Duplicate email not allowed")));
//        // response.andExpect(status().isBadRequest());
// }
//    @Test
//    @DisplayName("Get User by roles 404 status check")
//    @WithMockUser(username = "admin",roles = {"ADMIN","USER"})
//    void givenRoles_whenCallGetUserByRolesEntity_thenReturnUser() throws Exception {
//        //given
//        //User user = objectMapper.readValue(Payload.userPayload(), User.class);
//
//       // Optional<List<User>> userByRoles = null;
//        given(userService.getUserByRolesEntity(any(String.class))).willReturn(Optional.ofNullable(null));
//        //when
//        ResultActions response = mockMvc.perform(get("/roles/{roles}", "manager"));
//        //then
//        response.andExpect(status().isNotFound());
//    }
//
//    @Test
//    @DisplayName("Get User by roles 200 status check")
//    @WithMockUser(username = "admin",roles = {"ADMIN","USER"})
//    void givenRoles_whenCallGetUserByRolesEntity_thenReturn() throws Exception{
//        List<User> userList =new ArrayList<>();
//        userList.add(user);
//        given(userService.getUserByRolesEntity(any(String.class))).willReturn(Optional.of(userList));
//        //when
//        ResultActions response = mockMvc.perform(get("/roles/hr"));
//        //then
//        response.andExpect(status().isOk());
//    }
//}
//
//
