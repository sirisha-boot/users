//package com.example.users.service;
//
//import com.example.users.model.User;
//import com.example.users.repository.UserRepository;
//import com.fasterxml.jackson.core.JsonProcessingException;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.junit.jupiter.MockitoExtension;
//
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Optional;
//
//import static org.assertj.core.api.Assertions.assertThat;
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.junit.jupiter.api.Assertions.assertThrows;
//import static org.mockito.ArgumentMatchers.any;
//import static org.mockito.BDDMockito.given;
//
//@ExtendWith(MockitoExtension.class)
//public class UserServiceTest
//{
//    @Mock
//    UserRepository userRepository;
//
//    @InjectMocks
//    private UserService userService;
//User user;
//String userJson;
//    private ObjectMapper objectMapper = new ObjectMapper();
//
// //  private UserReponse userResponse;
//@BeforeEach
//void setup() throws JsonProcessingException {
//
//    List<String> managerName=new ArrayList<>();
//    managerName.add("suresh");
//    //managerName.add("manager");
//
//    user=User.builder()
//            .id("123")
//            .firstName("java")
//            .middleName("bo")
//            .email("userkn@test.com")
//            .contact("1234")
//            .managerName(managerName).build();
//
////    userResponse=   UserReponse.builder()
////            .id("123")
////            .roles(roles)
////            .email("user@gmail.com")
////            .build();
//
//
//    userJson = objectMapper.writeValueAsString(user);
//}
//
//    @Test
//    void givenEmail_whenCallGetUserByEmailEntity_thenReturnEmail() {
//    //given
//    String email = "test1@gmail.com";
//
//    given(userRepository.findByEmail(email)).willReturn(Optional.ofNullable(user));
//
//    //when
//    Optional<User> userEntity = userService.getUserByEmailEntity(email);
//
//    //then
//    assertThat(userEntity).isPresent();
//    assertEquals("123", userEntity.get().getId());
//    // assertEquals("test1@gmail.com", userEntity.get().getEmail());
//
//}
//
////    @Test
////    void givenUser_whenCallGetUserByEmailEntity_thenReturnException() throws Exception {
////        //given
////        String email = "test1@gmail.com";
////
////        given(userRepository.findByEmail(email)).willReturn(new RuntimeException());
////
////        //when
////// Optional<UserReponse> userEntity = userService.getUserByEmailEntity(email);
////
////        //then
////        Assertions.assertThatThrownBy(()-> {
////                    String userReponse = new String();
////                    userService.getUserByEmailEntity(userReponse);
////                }).isInstanceOf(UserAlreadyExistsException.class)
////                .hasMessageContaining("Email already exists. Duplicate email not allowed");
////    }
//    @Test
//    void givenUser_whenCallCreateUser_thenReturnUserResponse() throws Exception {
//
//        User userReponse = new User();
//        given(userRepository.save(any(User.class))).willReturn(userReponse);
//
//        //when
//        User userRes = userService.createUser(user);
//
//        //then
//        assertThat(userRes).isNotNull();
//        assertThat(userRes.getId()).isNotNull();
//        assertThat(userRes.getId()).isEqualTo("123");
//    }
//
//    @Test
//    void givenUser_whenCallGetUserByRolesEntity_thenReturnListUsers() throws Exception {
//        List<User> userList = new ArrayList<>();
//        userList.add(user);
//        given(userRepository.findAllByRoles(any(String.class))).willReturn(Optional.of(userList));
//        Optional<List<User>> userResp=userService.getUserByRolesEntity("hr");
//        assertThat(userResp).isNotNull();
//    }
//}
//
//
