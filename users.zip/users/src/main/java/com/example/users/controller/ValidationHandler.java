package com.example.users.controller;

import com.example.users.exception.UserAlreadyExistsException;
import com.example.users.exception.UserNotFoundException;
import com.example.users.model.ErrorDetail;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.util.HashMap;
import java.util.Map;

@ControllerAdvice
public class ValidationHandler extends ResponseEntityExceptionHandler {

   static final String DOC_URL = "https://modeeleven.com/docs/error-codes";

    @ExceptionHandler(UserAlreadyExistsException.class)
    public ResponseEntity<ErrorDetail> handleUserAlreadyExistsException(UserAlreadyExistsException ex) {
        ErrorDetail error = new ErrorDetail("422", DOC_URL, ex.getMessage());
        return new ResponseEntity<>(error, HttpStatus.UNPROCESSABLE_ENTITY);
    }

    @ExceptionHandler(UserNotFoundException.class)
    public ResponseEntity<ErrorDetail> handleUserNotFoundException(UserNotFoundException ex) {
        ErrorDetail error = new ErrorDetail("404", DOC_URL, ex.getMessage());
        return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
    }
}
