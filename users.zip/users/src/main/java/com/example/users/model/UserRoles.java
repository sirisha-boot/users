package com.example.users.model;


public enum UserRoles {

    USER_ROLES1("EMPLOYEE"),
    USER_ROLES2("MANAGER"),
    USER_ROLES3("ADMIN");
     private String value;

     UserRoles (String value)
     {
         this.value=value;
     }

    public String getValue() {
        return value;
    }
}
