package com.example.users.service;

import com.example.users.model.User;
import com.example.users.model.UserRoles;
import com.example.users.repository.UserRepository;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;


import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
@Service
@Slf4j
public class UserService {
//    User userReponse;
    @Autowired
    UserRepository userRepository;
    ModelMapper modelMapper = new ModelMapper();


    User user;

    //Roles roles;
    public Optional<User> getUserByEmailEntity(String email) {
        return userRepository.findByEmail(email);
    }

    public User createUser(User user) {
        this.user = userRepository.save(user);
        user = modelMapper.map(user, User.class);
        return user;

    }

    public Optional<List<User>> getUserByRolesEntity(List<String> roles) {
//roles =manager/hr
        return userRepository.findByUserRoleIn(roles);
    }

    public Optional<List<User>> getAllUsers() {
        User userDetails = getUserByEmailEntity(SecurityContextHolder.getContext().getAuthentication().getName()).get();
        List<String> rolesList= userDetails.getUserRole();
       if(rolesList.contains(UserRoles.USER_ROLES3.getValue())) {
           List<String> roles=new ArrayList<>();
           roles.add(UserRoles.USER_ROLES2.getValue());
           roles.add(UserRoles.USER_ROLES1.getValue());
           return userRepository.findByUserRoleIn(roles);
       }
           else if(rolesList.contains(UserRoles.USER_ROLES2.getValue()))
           return userRepository.findByUserRoleAndManagerName(UserRoles.USER_ROLES1.getValue(),userDetails.getFirstName());
               else {
           List<User> user=new ArrayList<>();
           user.add(getUserByEmailEntity(SecurityContextHolder.getContext().getAuthentication().getName()).get());
           return Optional.of(user);
       }
    }
}
