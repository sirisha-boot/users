package com.example.users.service;
//
//import com.example.tokensample.entity.User;
//import com.example.tokensample.repository.UserRepository;
import com.example.users.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class CustomUserDetailsService implements UserDetailsService {
    @Autowired
    private UserRepository repository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        com.example.users.model.User user = repository.findByEmail(username).get();
       if (user!=null) {
            return   new User(user.getEmail(), user.getPassword(),new ArrayList<>());
        } else {
            throw new UsernameNotFoundException("User not found with userName: " + username);
        }
    }
}


//
//import java.util.ArrayList;
//
//import org.springframework.security.core.userdetails.User;
//import org.springframework.security.core.userdetails.UserDetails;
//import org.springframework.security.core.userdetails.UserDetailsService;
//import org.springframework.security.core.userdetails.UsernameNotFoundException;
//import org.springframework.stereotype.Service;
//
//@Service
//public class CustomUserDetailsService  implements UserDetailsService {
//
//    @Override
//    public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {
//        if (userName.equals("Java")) {
//            return new User("Java", "pswd",
//                    new ArrayList<>());
//        } else {
//            throw new UsernameNotFoundException("User not found with userName: " + userName);
//        }
//       }
//}
