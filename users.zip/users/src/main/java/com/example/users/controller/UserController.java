package com.example.users.controller;

import com.example.users.exception.UserAlreadyExistsException;
import com.example.users.exception.UserNotFoundException;
import com.example.users.model.User;
import com.example.users.service.UserService;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;
@RestController
@Slf4j
public class UserController {

    @Autowired
    UserService userService;

    @SneakyThrows
    @ResponseStatus(HttpStatus.CREATED)
    @PostMapping(path = "/users")
    public User createUser(@Valid @RequestBody User user) {

        Optional<User> userEmail = userService.getUserByEmailEntity(user.getEmail());
        if (!userEmail.isPresent()) {
            return userService.createUser(user);
        }
        throw new UserAlreadyExistsException("Email already exists. Duplicate email not allowed");
    }

//    @GetMapping(path = "/test")
//    public String hello() {
//        return "hello java,localhost 8081";
//    }

    @GetMapping(path = "/getUsers")
    public Optional<List<User>> getAllUsers() throws UserNotFoundException {
        Optional<List<User>> userList = userService.getAllUsers();
        if (userList.isPresent()) {
            return userList;
        }
        throw new UserNotFoundException("User not found for role");
    }

}