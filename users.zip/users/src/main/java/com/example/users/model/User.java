package com.example.users.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import lombok.*;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;
//import java.io.Serial;
import java.io.Serializable;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class User  {

    private String id;
    private String firstName;
    private String password;
    @NonNull
    @Valid
    private String email;
    List<String> managerName;
    List<String> userRole;
    private String contact;



}